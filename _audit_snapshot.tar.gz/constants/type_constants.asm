; TypeNames indexes (see data/types/names.asm)
	const_def

DEF PHYSICAL EQU const_value
	const NORMAL       ; $00
	const FIGHTING     ; $01
	const FLYING       ; $02
	const POISON       ; $03
	const GROUND       ; $04
	const ROCK         ; $05
	const BIRD         ; $06
	const BUG          ; $07
	const DRAGON       ; $08

DEF UNUSED_TYPES EQU const_value
	const DARK         ; $09
	const STEEL        ; $0A
	const_skip 9 ; reserve $0B–$13 so FIRE stays at $14
DEF UNUSED_TYPES_END EQU const_value

DEF SPECIAL EQU const_value
	const FIRE         ; $14
	const WATER        ; $15
	const GRASS        ; $16
	const ELECTRIC     ; $17
	const PSYCHIC_TYPE ; $18
	const ICE          ; $19
	const GHOST        ; $1A

DEF NUM_TYPES EQU const_value
